"use client"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { formatRupiah } from "@/lib/utils"
import { plans } from "@/data/plans"
import { Loader2 } from "lucide-react"

interface ConfirmationDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  planId: string
  onConfirm: () => void
  isLoading: boolean
}

export function ConfirmationDialog({ open, onOpenChange, planId, onConfirm, isLoading }: ConfirmationDialogProps) {
  const plan = plans.find((p) => p.id === planId)

  if (!plan) return null

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md premium-card border-white/10 text-white">
        <DialogHeader>
          <DialogTitle className="text-xl text-cyan-300">Konfirmasi Pembelian</DialogTitle>
          <DialogDescription className="text-gray-400">
            Anda akan membeli paket <span className="font-semibold text-white">{plan.name}</span>
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="bg-white/[0.04] p-4 rounded-xl border border-white/10">
            <h3 className="font-medium text-white mb-2">Detail Paket</h3>
            <div className="grid grid-cols-2 gap-2 text-sm">
              <div className="text-gray-400">RAM:</div>
              <div className="font-medium text-white">{plan.memory} MB</div>
              <div className="text-gray-400">Disk:</div>
              <div className="font-medium text-white">{plan.disk} MB</div>
              <div className="text-gray-400">CPU:</div>
              <div className="font-medium text-white">{plan.cpu}%</div>
              <div className="text-gray-400">Harga:</div>
              <div className="font-medium text-cyan-300">{formatRupiah(plan.price)}</div>
            </div>
          </div>
          <p className="text-sm text-gray-400">
            Dengan mengklik tombol "Lanjutkan Pembayaran", Anda akan diarahkan ke halaman pembayaran.
          </p>
        </div>
        <DialogFooter className="flex flex-col sm:flex-row sm:justify-between gap-2">
          <Button
            variant="outline"
            onClick={() => onOpenChange(false)}
            className="w-full sm:w-auto bg-white/5 border-white/10 hover:bg-white/10 text-white"
          >
            Batal
          </Button>
          <Button onClick={onConfirm} className="w-full sm:w-auto premium-button" disabled={isLoading}>
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Memproses...
              </>
            ) : (
              "Lanjutkan Pembayaran"
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
